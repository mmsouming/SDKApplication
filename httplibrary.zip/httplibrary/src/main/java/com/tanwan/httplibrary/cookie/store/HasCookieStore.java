package com.tanwan.httplibrary.cookie.store;

/**
 * Created by zhy on 16/3/10.
 */
public interface HasCookieStore
{
    CookieStore getCookieStore();
}
